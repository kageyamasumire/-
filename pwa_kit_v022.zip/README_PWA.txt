PWA 追加差分（v0.22）
1) このフォルダの `manifest.webmanifest` / `sw.js` / `icons/` をリポジトリ root にアップロード
2) `index.html` の <head> に manifest と iOSタグを追加、</body> 直前に SW 登録スクリプトを追加
3) 反映後、ページをリロード → Offlineで表示確認 → iPhoneでホーム画面に追加
